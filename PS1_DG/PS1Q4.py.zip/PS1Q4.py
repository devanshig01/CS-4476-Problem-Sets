import numpy as np
import matplotlib.pyplot as plt
import cv2
from skimage import color, io

class Prob4():
    def __init__(self):
        """Load input color image indoor.png and outdoor.png here as class variables."""

        self.indoor = io.imread("indoor.png")
        self.outdoor = io.imread("outdoor.png")
       
    
    def prob_4_1(self):
        """Plot R,G,B channels separately and also their corresponding LAB space channels separately"""
        
        indoor_red = self.indoor[:, :, 0]
        indoor_green = self.indoor[:, :, 1]
        indoor_blue = self.indoor[:, :, 2]
        outdoor_red = self.outdoor[:, :, 0]
        outdoor_green = self.outdoor[:, :, 1]
        outdoor_blue = self.outdoor[:, :, 2]
       
        
        



        return

    def prob_4_2(self):
        """
        Convert the loaded RGB image to HSV and return HSV matrix without using inbuilt functions. Return the HSV image as HSV. Make sure to use a 3 channeled RGB image with floating point values lying between 0 - 1 for the conversion to HSV.

        Returns:
            HSV image (3 channeled image with floating point values lying between 0 - 1 in each channel)
        """
       
        np.seterr(invalid='ignore')
        
        RGB = io.imread('inputPS1Q4.jpg') 


        RGB = RGB / 255.0
        RGB = RGB.astype('float64')
        R = RGB[:, :, 0]
        G = RGB[:, :, 1]
        B = RGB[:, :, 2]
        
        V = np.max(RGB, axis = 2)
       
        m = np.min(RGB, axis = 2)
        C = V - m
        S = C
        if (np.all(V == 0)):
            S = 0
        else:
            S = np.divide(C, V)
        Hh = C
        Hh[C == 0] = 0
        Hh[V == R] = (G[V == R] - B[V == R]) / C[V == R]
        Hh[V == G] = ((B[V == G] - R[V == G]) / C[V == G]) + 2
        Hh[V == B] = ((R[V == B] - G[V == B]) / C[V == B]) + 4
        H = Hh / 6
        H[H < 0] += 1

        H = Hh / 6
        H[H < 0] += 1
        
        HSV = np.dstack((H, S, V))       
        HSV = np.nan_to_num(HSV)

       
        plt.imshow(HSV, cmap='hsv')
        plt.show()
        return HSV
        
        '''
        V = np.max(RGB, axis = 2)
       
        m = np.min(RGB, axis = 2)
        C = V - m
        S = C
        if (np.all(V == 0)):
            S = 0
        else:
            S = np.divide(C, V)
        Hh = C
        Hh[C == 0] = 0
        Hh[V == R] = (G[V == R] - B[V == R]) / C[V == R]
        Hh[V == G] = ((B[V == G] - R[V == G]) / C[V == G]) + 2
        Hh[V == B] = ((R[V == B] - G[V == B]) / C[V == B]) + 4
        H = Hh / 6
        H[H < 0] += 1
    
        HSV = np.dstack((H, S, V))       
        plt.imshow(HSV)
        plt.show()

        return HSV
        '''

        
if __name__ == '__main__':
    
    p4 = Prob4()
    p4.prob_4_1()
    HSV = p4.prob_4_2()





